<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pelanggan extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		if(!$this->session->userdata('login')){
			redirect('error/error_401','refresh');
		}if (!$this->session->userdata('user_id_admin')) {
			redirect('home','refresh');
		}
		$this->load->library('form_validation');
		$this->load->model('m_pelanggan','pelanggan');
	}

	public function index()
	{
		$data['view'] = 'page/pelanggan/index';	
		$data['dataAll'] = $this->pelanggan->getAll();
		$data['judul'] = "<h2>Pelanggan</h2>";
		$data['data_tarif'] = $this->pelanggan->getTarif();
		$data['validation'] = 'validation';
		$this->load->view('layout/index', $data);
		
	}

	public function add()
	{		
		if(isset($_POST) && count($_POST) > 0){			
			$this->form_validation->set_rules($this->pelanggan->rules());
			$this->form_validation->set_message('checkNoMeter','No Meter Sudah Dipakai');
			$this->form_validation->set_message('checkUsername','Username Sudah Dipakai');
			if (!$this->form_validation->run()) {
				$data['error'] = true;
				$data['error_msg'] = $this->pelanggan->error_msg();
			}else{
				$object = array(
					'no_meter' => $this->input->post('no_meter',true),
					'nama' => $this->input->post('nama',true),
					'username' => $this->input->post('username',true),
					'password' => $this->input->post('password',true),
					'alamat' => $this->input->post('alamat',true),
					'id_tarif' => $this->input->post('id_tarif',true), 
				);
				$this->pelanggan->add($object);
				$data['success'] = true;
				$data['redirect'] = 'pelanggan';
			}
			echo json_encode($data);
		}else{
			redirect('pelanggan','refresh');
		}
	}

	public function edit_data($id)
	{
		$data = $this->pelanggan->getById($id);
		echo json_encode($data);
	}

	public function ubah()
	{		
		if(isset($_POST['id_tarif']) && count($_POST) > 0){			
			$this->form_validation->set_rules($this->pelanggan->rulesEdit());
			$this->form_validation->set_message('checkNoMeter','No Meter Sudah Dipakai');
			$this->form_validation->set_message('checkEmail','Username Sudah Dipakai');
			if (!$this->form_validation->run()) {
				$data['error'] = true;
				$data['error_msg'] = $this->pelanggan->error_msg();
			}else{
				$object = array(
					'no_meter' => $this->input->post('no_meter'),
					'username' => $this->input->post('username',true),
					'nama' => $this->input->post('nama'),
					'alamat' => $this->input->post('alamat'),
					'id_tarif' => $this->input->post('id_tarif'), 
				);
				$this->pelanggan->update($object,$this->input->post('id_pelanggan'));
				$data['success'] = true;
				$data['redirect'] = 'pelanggan';
			}
			echo json_encode($data);
		}else{
			redirect('pelanggan','refresh');
		}
	}

	public function delete($id)
	{		
		if ($this->pelanggan->delete($id)) {						
			redirect('pelanggan/index','refresh');
		}else{
			echo '<script>alert("Data tidak dapat dihapus");</script>';
			redirect('pelanggan','refresh');
		}
	}

	public function checkNoMeter($str)
	{
		$id =  $this->input->post('id_pelanggan');
		if ($id) {
			$data_no_meter=$this->db->select('no_meter')->where('id_pelanggan',$id)->get('pelanggan')->row();
			if ($str == $data_no_meter->no_meter) {
				return true;
			}else{
				$data = $this->db->get_where('pelanggan',array('no_meter'=>$str))->num_rows();
				if ($data>0) {
					return false;
				}else{
					return true;
				}
			}
		}else{
			$data = $this->db->get_where('pelanggan',array('no_meter'=>$str))->num_rows();
			if ($data>0) {
				return false;
			}else{
				return true;
			}
		}	
	}

	public function checkUsername($str)
	{
		$id =  $this->input->post('id_pelanggan');
		if ($id) {
			$data_no_meter=$this->db->select('username')->where('id_pelanggan',$id)->get('pelanggan')->row();
			if ($str == $data_no_meter->username) {
				return true;
			}else{
				$data = $this->db->get_where('pelanggan',array('username'=>$str))->num_rows();
				if ($data>0) {
					return false;
				}else{
					return true;
				}
			}
		}else{
			$data = $this->db->get_where('pelanggan',array('username'=>$str))->num_rows();
			if ($data>0) {
				return false;
			}else{
				return true;
			}
		}
	}
}

/* End of file Pelanggan.php */
/* Location: ./application/controllers/Pelanggan.php */