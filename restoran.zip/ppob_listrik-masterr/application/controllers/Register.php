<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Register extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->library('form_validation');
		$this->load->model('m_user','user');
	}

	public function index()
	{
		if (!$this->session->userdata('login')) {
			$data['validation'] = 'validation';			
			$data['tarif'] = $this->user->getTarif();
			$this->load->view('page/register/index',$data);	
		}else{
			redirect('home','refresh');
		}
	}

	public function validate()
	{
		if(isset($_POST) && count($_POST) > 0){	
			$this->form_validation->set_rules($this->user->rulesDaftar());	
			$this->form_validation->set_message('checkNoMeter', 'No Meter Sudah Dipakai');
			$this->form_validation->set_message('checkUsername', 'username Sudah Dipakai');
			if (!$this->form_validation->run()) {				
				$data['error']=true;
				$data['error_msg']=$this->user->error_msg_daftar();
			} else {
				$object = array(
					'no_meter' => $this->input->post('no_meter',true),
					'nama' => $this->input->post('nama',true),
					'username' => $this->input->post('username',true),
					'password' => md5($this->input->post('password',true)),
					'alamat' => $this->input->post('alamat',true),					
					'id_tarif' => $this->input->post('id_tarif',true),
				);
				$this->user->insertPelanggan($object);
				$data['success'] = true;
				$data['redirect'] = 'home';				
			}
			echo json_encode($data);
		}
	}

	public function checkNoMeter($str)
    {    
    	$data = $this->db->get_where('pelanggan',array('no_meter' =>$str))->num_rows();
    	if ($data==1) {
    		return false;
    	}else{
    		return true;
    	}    	
    }

    public function checkUsername($str)
    {
    	$data = $this->db->get_where('pelanggan',array('username' => $str))->num_rows();
    	$data2 = $this->db->get_where('admin',array('username' => $str))->num_rows();
    	if ($data==1 || $data2==1) {
    		return false;
    	}else{
    		return true;
    	}    	
    }

}

/* End of file Register.php */
/* Location: ./application/controllers/Register.php */