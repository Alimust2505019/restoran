<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Verifikasi extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		if(!$this->session->userdata('login')){
			redirect('error/error_401','refresh');
		}if (!$this->session->userdata('user_id_admin')) {
			redirect('home','refresh');
		}
		$this->load->library('form_validation');
		$this->load->model('m_verifikasi','verifikasi');
	}

	public function index()
	{
		$data['view'] = 'page/verifikasi/index';	
		$data['judul'] = "<h2>Verifikasi</h2>";
		$data['data_pembayaran'] = $this->verifikasi->getAll();		
		$data['validation'] = 'validation';
		$this->load->view('layout/index', $data);
		
	}

	public function ubah()
	{		
		if(isset($_POST['id_tagihan']) && count($_POST) > 0){			
			$this->form_validation->set_rules('status','Status','required');
			if (!$this->form_validation->run()) {
		      $data['error'] = true;
		      $data['error_msg'] = array('status'=>form_error('status'));
		    }else{
		      $object = array(
					'status' => $this->input->post('status'), 					
			  );
		      $this->verifikasi->update($object,$this->input->post('id_tagihan'));
		      $data['success'] = true;
		      $data['redirect'] = 'verifikasi';
		    }
		    echo json_encode($data);
		}else{
			redirect('verifikasi','refresh');
		}
	}

}

/* End of file Verifikasi.php */
/* Location: ./application/controllers/Verifikasi.php */