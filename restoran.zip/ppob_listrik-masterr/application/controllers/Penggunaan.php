<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Penggunaan extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		if(!$this->session->userdata('login')){
			redirect('error/error_401','refresh');
		}if (!$this->session->userdata('user_id_admin')) {
			redirect('home','refresh');
		}
		$this->load->library('form_validation');
		$this->load->model('m_penggunaan','penggunaan');
	}

	public function index()
	{				
		$data['data_pelanggan'] = $this->penggunaan->getPelanggan();
		$data['tahun'] = array(2016,2017,2018,2019,2020);		
		$data['bulan'] = array(
			['id' => 1,'bulan' =>'Januari'],
			['id' => 2,'bulan' =>'Februari'],
			['id' => 3,'bulan' =>'Maret'],
			['id' => 4,'bulan' =>'April'],
			['id' => 5,'bulan' =>'Mei'],
			['id' => 6,'bulan' =>'Juni'],
			['id' => 7,'bulan' =>'Juli'],
			['id' => 8,'bulan' =>'Agustus'],
			['id' => 9,'bulan' =>'September'],
			['id' => 10,'bulan' =>'Oktober'],
			['id' => 11,'bulan' =>'November'],
			['id' => 12,'bulan' =>'Desember'],
		);
		// $data['js_tambahan'] = 'dropdown_penggunaan';
		$data['view'] = 'page/penggunaan/index';			
		$data['judul'] = "<h2>Penggunaan</h2>";
		$data['validation'] = 'validation';
		$this->load->view('layout/index', $data);
	}

	public function add()
	{		
		if(isset($_POST) && count($_POST) > 0){			
			$this->form_validation->set_rules($this->penggunaan->rules());
			if (!$this->form_validation->run()) {
				$data['error'] = true;
				$data['error_msg'] = $this->penggunaan->error_msg();
			}else{
				$id_pelanggan = $this->input->post('id_pelanggan');
				$bulan = $this->input->post('bulan');
				$tahun = $this->input->post('tahun');
				$meteran_awal = $this->input->post('meteran_awal');
				$meteran_akhir = $this->input->post('meteran_akhir');
				if ($this->penggunaan->checkPengunaan($bulan,$tahun,$id_pelanggan)) {
					$data['false'] = true;
					$data['false_msg'] = 'Penggunaan Sudah Ada';
				}else if ($meteran_akhir < $meteran_awal) {
					$data['false'] = true;
					$data['false_msg'] = 'Penginputan Meteran Salah';
				}
				else{
					$object = array(
						'bulan' => $bulan,
						'tahun' => $tahun,
						'meteran_awal' => $meteran_awal,
						'meteran_akhir' => $meteran_akhir,
						'id_pelanggan' => $id_pelanggan,
					);
					$this->penggunaan->add($object);
					$data['success'] = true;
					$data['redirect'] = 'penggunaan';
				}
			}
			echo json_encode($data);
		}else{
			redirect('penggunaan','refresh');
		}
	}

	public function detail()
	{
		if ($this->session->flashdata('id_pelanggan')) {
			$id_pelanggan = $this->session->flashdata('id_pelanggan');
		}else{
			$id_pelanggan = $this->input->post('id_pelanggan');
		}
		if ($this->penggunaan->checkPelanggan($id_pelanggan)>0) {
			$user = $this->db->select('nama,daya')->where('id_pelanggan',$id_pelanggan)->join('tarif','tarif.id_tarif=pelanggan.id_tarif')->get('pelanggan')->row();
			$data['nama'] = $user->nama;
			$data['daya'] = $user->daya;
			$data['bulan'] = array(
				1=>'Januari',2=>'Februari',3=>'Maret',4=>'April',5=>'Mei',6=>'Juni',
				7=>'Juli',8=>'Agustus',9=>'September',10=>'Oktober',11=>'November',12=>'Desember',
			);
			$data['detail'] = $this->penggunaan->getTagihanByIdPelanggan($id_pelanggan);
			$data['view'] = "page/penggunaan/detail";

			$this->load->view('layout/index', $data);
		}else{
			redirect('penggunaan','refresh');
		}
	}

	public function delete()
	{
		$id_tagihan = $this->input->post('id_tagihan',true);
		$id_penggunaan = $this->input->post('id_penggunaan',true);		
		if ($id_tagihan!== '' && $id_penggunaan!=='') {
			$this->penggunaan->deletePenggunaanTagihan($id_tagihan,$id_penggunaan);
			$this->session->set_flashdata('id_pelanggan', $this->input->post('id_pelanggan',true));
			redirect('penggunaan/detail','refresh');
		}else{
			redirect('penggunaan','refresh');
		}
	}
}

/* End of file Penggunaan.php */
/* Location: ./application/controllers/Penggunaan.php */