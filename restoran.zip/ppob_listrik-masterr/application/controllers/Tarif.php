<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Tarif extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		if(!$this->session->userdata('login')){
			redirect('error/error_401','refresh');
		}if (!$this->session->userdata('user_id_admin')) {
			redirect('home','refresh');
		}
		$this->load->library('form_validation');
		$this->load->model('m_tarif','tarif');
	}

	public function index()
	{
		$data['view'] = 'page/tarif/index';	
		$data['dataAll'] = $this->tarif->getAll();
		$data['judul'] = "<h2>Tarif</h2>";
		$data['validation'] = 'validation';
		$this->load->view('layout/index', $data);
		
	}

	public function add()
	{		
		if(isset($_POST) && count($_POST) > 0){			
			$this->form_validation->set_rules($this->tarif->rules());
			if (!$this->form_validation->run()) {
		      $data['error'] = true;
		      $data['error_msg'] = $this->tarif->error_msg();
		    }else{
		      $object = array(
					'daya' => $this->input->post('daya'), 
					'perkwh' => $this->input->post('perkwh'), 
			  );
		      $this->tarif->add($object);
		      $data['success'] = true;
		      $data['redirect'] = 'tarif';
		    }
		    echo json_encode($data);
		}else{
			redirect('tarif','refresh');
		}
	}

	public function edit_data($id)
	{
		$data = $this->tarif->getById($id);
		echo json_encode($data);
	}

	public function ubah()
	{		
		if(isset($_POST['id_tarif']) && count($_POST) > 0){			
			$this->form_validation->set_rules($this->tarif->rules());
			if (!$this->form_validation->run()) {
		      $data['error'] = true;
		      $data['error_msg'] = $this->tarif->error_msg();
		    }else{
		      $object = array(
				'daya' => $this->input->post('daya', true), 
				'perkwh' => $this->input->post('perkwh', true), 
			  );
		      $this->tarif->update($object,$this->input->post('id_tarif'));
		      $data['success'] = true;
		      $data['redirect'] = 'tarif';
		    }
		    echo json_encode($data);
		}else{
			redirect('tarif','refresh');
		}
	}

	public function delete($id)
	{		
		if ($this->tarif->delete($id)) {			
			$this->session->set_flashdata('cek', 'value');
			redirect('tarif/index','refresh');
		}else{
			echo '<script>alert("Data tidak dapat dihapus");</script>';
			redirect('tarif','refresh');
		}
	}

}

/* End of file Tarif.php */
/* Location: ./application/controllers/Tarif.php */